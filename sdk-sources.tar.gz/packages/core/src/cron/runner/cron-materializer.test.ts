import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import {
	ONE_TIME_SCHEDULE_CRON_PATTERN,
	ONE_TIME_SCHEDULE_RUN_AT_METADATA_KEY,
} from "@sctg/cline-shared";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { SqliteCronStore } from "../store/sqlite-cron-store";
import { CronMaterializer } from "./cron-materializer";

describe("CronMaterializer", () => {
	let dir: string;
	let store: SqliteCronStore;

	beforeEach(() => {
		dir = mkdtempSync(join(tmpdir(), "cline-materializer-"));
		store = new SqliteCronStore({ dbPath: join(dir, "cron.db") });
	});
	afterEach(() => {
		store.close();
		rmSync(dir, { recursive: true, force: true });
	});

	function seedOneOff() {
		return store.upsertSpec({
			externalId: "cleanup",
			sourcePath: "cleanup.md",
			triggerKind: "one_off",
			sourceHash: "h",
			parseStatus: "valid",
			spec: {
				triggerKind: "one_off",
				id: "cleanup",
				title: "Clean",
				prompt: "p",
				workspaceRoot: "/ws",
				enabled: true,
			},
		}).record;
	}

	function requireValue<T>(value: T | undefined): T {
		expect(value).toBeDefined();
		if (value === undefined) {
			throw new Error("Expected value to be defined");
		}
		return value;
	}

	it("queues exactly one run per one-off spec revision", () => {
		seedOneOff();
		const m = new CronMaterializer({ store });
		expect(m.materializeAll().oneOffQueued).toBe(1);
		expect(m.materializeAll().oneOffQueued).toBe(0);
	});

	it("preserves a future run time when materializing a one-off spec", () => {
		const spec = seedOneOff();
		const runAt = new Date(Date.now() + 60_000).toISOString();
		store.updateSpecNextRunAt(spec.specId, runAt);
		const materializer = new CronMaterializer({ store });

		expect(materializer.materializeAll().oneOffQueued).toBe(1);
		expect(store.listRuns({ specId: spec.specId })[0]?.scheduledFor).toBe(
			runAt,
		);
	});

	it("replaces a queued one-time run when its timestamp changes", () => {
		const originalRunAt = Date.now() + 60_000;
		const rescheduledRunAt = originalRunAt + 60 * 60_000;
		const spec = store.createHubSchedule({
			name: "Run once",
			cronPattern: ONE_TIME_SCHEDULE_CRON_PATTERN,
			prompt: "Do the work",
			workspaceRoot: "/ws",
			metadata: {
				[ONE_TIME_SCHEDULE_RUN_AT_METADATA_KEY]: originalRunAt,
			},
		});
		const materializer = new CronMaterializer({ store });
		expect(materializer.materializeAll().oneOffQueued).toBe(1);

		const updated = requireValue(
			store.updateHubSchedule(spec.externalId, {
				scheduleId: spec.externalId,
				metadata: {
					[ONE_TIME_SCHEDULE_RUN_AT_METADATA_KEY]: rescheduledRunAt,
				},
			}),
		);

		expect(updated.revision).toBe(spec.revision + 1);
		expect(updated.nextRunAt).toBe(new Date(rescheduledRunAt).toISOString());
		expect(materializer.materializeAll().oneOffQueued).toBe(1);
		const runs = store.listRuns({ specId: spec.specId });
		expect(runs).toHaveLength(2);
		expect(runs.filter((run) => run.status === "cancelled")).toEqual([
			expect.objectContaining({
				specRevision: spec.revision,
				scheduledFor: new Date(originalRunAt).toISOString(),
			}),
		]);
		expect(runs.filter((run) => run.status === "queued")).toEqual([
			expect.objectContaining({
				specRevision: updated.revision,
				scheduledFor: new Date(rescheduledRunAt).toISOString(),
			}),
		]);
	});

	it("keeps only one queued run after pausing and resuming a one-time schedule", () => {
		const runAt = Date.now() + 60_000;
		const spec = store.createHubSchedule({
			name: "Run once",
			cronPattern: ONE_TIME_SCHEDULE_CRON_PATTERN,
			prompt: "Do the work",
			workspaceRoot: "/ws",
			metadata: { [ONE_TIME_SCHEDULE_RUN_AT_METADATA_KEY]: runAt },
		});
		const materializer = new CronMaterializer({ store });
		expect(materializer.materializeAll().oneOffQueued).toBe(1);

		const paused = requireValue(
			store.updateHubSchedule(spec.externalId, {
				scheduleId: spec.externalId,
				enabled: false,
			}),
		);
		expect(paused.enabled).toBe(false);
		expect(
			store.listRuns({ specId: spec.specId, status: "queued" }),
		).toHaveLength(0);
		expect(materializer.materializeAll().oneOffQueued).toBe(0);

		const resumed = requireValue(
			store.updateHubSchedule(spec.externalId, {
				scheduleId: spec.externalId,
				enabled: true,
			}),
		);
		expect(resumed.revision).toBe(spec.revision + 1);
		expect(materializer.materializeAll().oneOffQueued).toBe(1);
		const runs = store.listRuns({ specId: spec.specId });
		expect(runs).toHaveLength(2);
		expect(runs.filter((run) => run.status === "cancelled")).toHaveLength(1);
		expect(runs.filter((run) => run.status === "queued")).toEqual([
			expect.objectContaining({
				specRevision: resumed.revision,
				scheduledFor: new Date(runAt).toISOString(),
			}),
		]);
	});

	it("queues a new run when the revision bumps", () => {
		const spec = seedOneOff();
		const m = new CronMaterializer({ store });
		m.materializeAll();
		store.upsertSpec({
			externalId: "cleanup",
			sourcePath: "cleanup.md",
			triggerKind: "one_off",
			sourceHash: "h2",
			parseStatus: "valid",
			spec: {
				triggerKind: "one_off",
				id: "cleanup",
				title: "Clean",
				prompt: "new prompt",
				workspaceRoot: "/ws",
				enabled: true,
			},
		});
		const updated = requireValue(store.getSpec(spec.specId));
		expect(updated.revision).toBe(2);
		expect(m.materializeAll().oneOffQueued).toBe(1);
		const runs = store.listRuns({ specId: spec.specId });
		expect(runs.length).toBe(2);
	});

	it("does not requeue a failed one-off run for the same revision", () => {
		const spec = seedOneOff();
		const m = new CronMaterializer({ store });
		expect(m.materializeAll().oneOffQueued).toBe(1);
		const run = requireValue(store.listRuns({ specId: spec.specId })[0]);
		store.completeRun(run.runId, { status: "failed", error: "boom" });

		expect(m.materializeAll().oneOffQueued).toBe(0);
		const runs = store.listRuns({ specId: spec.specId });
		expect(runs).toHaveLength(1);
		expect(runs[0]?.status).toBe("failed");
	});

	it("catches up one overdue schedule run and advances next_run_at", () => {
		const past = new Date(Date.now() - 60_000).toISOString();
		const upserted = store.upsertSpec({
			externalId: "nightly",
			sourcePath: "nightly.cron.md",
			triggerKind: "schedule",
			sourceHash: "h",
			parseStatus: "valid",
			spec: {
				triggerKind: "schedule",
				id: "nightly",
				title: "Nightly",
				prompt: "p",
				workspaceRoot: "/ws",
				enabled: true,
				schedule: "* * * * *",
			},
		});
		// Force an overdue next_run_at.
		store.updateSpecNextRunAt(upserted.record.specId, past);

		const m = new CronMaterializer({ store });
		expect(m.materializeAll().scheduleQueued).toBe(1);
		expect(m.materializeAll().scheduleQueued).toBe(0);
		const after = requireValue(store.getSpec(upserted.record.specId));
		const nextRunAt = requireValue(after.nextRunAt);
		expect(new Date(nextRunAt).getTime()).toBeGreaterThan(Date.now());
	});

	it("does not duplicate a due schedule run when called twice with a stale spec snapshot", () => {
		const nowMs = Date.parse("2026-04-23T10:00:00.000Z");
		const dueAt = new Date(nowMs - 60_000).toISOString();
		const upserted = store.upsertSpec({
			externalId: "nightly",
			sourcePath: "nightly.cron.md",
			triggerKind: "schedule",
			sourceHash: "h",
			parseStatus: "valid",
			spec: {
				triggerKind: "schedule",
				id: "nightly",
				title: "Nightly",
				prompt: "p",
				workspaceRoot: "/ws",
				enabled: true,
				schedule: "* * * * *",
			},
		});
		store.updateSpecNextRunAt(upserted.record.specId, dueAt);
		const staleSpec = requireValue(store.getSpec(upserted.record.specId));
		const m = new CronMaterializer({ store, now: () => nowMs });

		expect(m.materializeSchedule(staleSpec)).toBe(true);
		expect(m.materializeSchedule(staleSpec)).toBe(false);

		const runs = store.listRuns({ specId: upserted.record.specId });
		expect(runs).toHaveLength(1);
		expect(runs[0]?.scheduledFor).toBe(dueAt);
	});
});
