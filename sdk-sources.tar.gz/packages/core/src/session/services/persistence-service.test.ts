import {
	existsSync,
	mkdtempSync,
	readFileSync,
	rmSync,
	writeFileSync,
} from "node:fs";
import { createRequire } from "node:module";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { afterEach, describe, expect, it, vi } from "vitest";
import { SqliteSessionStore } from "../../services/storage/sqlite-session-store";
import { SessionSource } from "../../types/common";
import { createSessionCompactionState } from "../models/session-compaction";
import { FileSessionService } from "../services/file-session-service";
import { CoreSessionService } from "../services/session-service";
import type { SessionPersistenceAdapter } from "./persistence-service";
import { UnifiedSessionPersistenceService } from "./persistence-service";

const require = createRequire(import.meta.url);
const sqliteAvailable = (() => {
	try {
		require("node:sqlite");
		return true;
	} catch {
		return false;
	}
})();

describe("UnifiedSessionPersistenceService", () => {
	const tempDirs: string[] = [];
	const stores: Array<SqliteSessionStore> = [];
	const sqliteIt = sqliteAvailable ? it : it.skip;

	afterEach(() => {
		for (const store of stores.splice(0)) {
			store.close();
		}
		for (const dir of tempDirs.splice(0)) {
			rmSync(dir, { recursive: true, force: true });
		}
	});

	it("persists compaction state as a separate session artifact", async () => {
		const sessionsDir = mkdtempSync(join(tmpdir(), "compaction-artifact-"));
		tempDirs.push(sessionsDir);
		const service = new FileSessionService(sessionsDir);
		const sessionId = "session-with-compaction";
		const artifacts = await service.createRootSessionWithArtifacts({
			sessionId,
			source: SessionSource.CLI,
			pid: process.pid,
			interactive: true,
			provider: "anthropic",
			model: "claude-sonnet",
			cwd: "/tmp/project",
			workspaceRoot: "/tmp/project",
			enableTools: true,
			enableSpawn: true,
			enableTeams: false,
			startedAt: "2026-01-01T00:00:00.000Z",
		});
		const sourceMessages = [
			{ id: "u1", role: "user" as const, content: "full transcript" },
		];
		const compactedMessages = [
			{ id: "summary", role: "user" as const, content: "summary" },
		];
		const state = createSessionCompactionState({
			sourceMessages,
			compactedMessages,
			conversationId: "conv-1",
			updatedAt: "2026-01-01T00:00:01.000Z",
		});
		expect(
			JSON.parse(readFileSync(artifacts.manifestPath, "utf8")),
		).not.toHaveProperty("compaction_path");
		expect(existsSync(artifacts.compactionPath ?? "")).toBe(false);

		await service.persistSessionMessages(sessionId, sourceMessages);
		await service.persistSessionCompactionState(sessionId, state);

		expect(
			JSON.parse(readFileSync(artifacts.manifestPath, "utf8")),
		).toHaveProperty("compaction_path", artifacts.compactionPath);
		const messagesPayload = JSON.parse(
			readFileSync(artifacts.messagesPath, "utf8"),
		) as { messages?: unknown[] };
		const compactionPayload = JSON.parse(
			readFileSync(artifacts.compactionPath ?? "", "utf8"),
		) as { messages?: unknown[]; source_message_count?: number };
		expect(messagesPayload.messages).toHaveLength(1);
		expect(compactionPayload).toMatchObject({
			source_message_count: 1,
			messages: compactedMessages,
		});
		await expect(
			service.readSessionCompactionState(sessionId),
		).resolves.toMatchObject({
			source_message_count: 1,
			messages: compactedMessages,
		});
	});

	it("deletes persisted compaction state without mutating canonical messages", async () => {
		const sessionsDir = mkdtempSync(join(tmpdir(), "compaction-delete-"));
		tempDirs.push(sessionsDir);
		const service = new FileSessionService(sessionsDir);
		const sessionId = "session-delete-compaction";
		const artifacts = await service.createRootSessionWithArtifacts({
			sessionId,
			source: SessionSource.CLI,
			pid: process.pid,
			interactive: true,
			provider: "anthropic",
			model: "claude-sonnet",
			cwd: "/tmp/project",
			workspaceRoot: "/tmp/project",
			enableTools: true,
			enableSpawn: true,
			enableTeams: false,
			startedAt: "2026-01-01T00:00:00.000Z",
		});
		const sourceMessages = [
			{ id: "u1", role: "user" as const, content: "full transcript" },
		];
		const state = createSessionCompactionState({
			sourceMessages,
			compactedMessages: [
				{ id: "summary", role: "user" as const, content: "summary" },
			],
			updatedAt: "2026-01-01T00:00:01.000Z",
		});

		await service.persistSessionMessages(sessionId, sourceMessages);
		await service.persistSessionCompactionState(sessionId, state);
		expect(existsSync(artifacts.compactionPath ?? "")).toBe(true);
		await service.deleteSessionCompactionState(sessionId);

		expect(existsSync(artifacts.messagesPath)).toBe(true);
		expect(existsSync(artifacts.compactionPath ?? "")).toBe(false);
		expect(
			JSON.parse(readFileSync(artifacts.manifestPath, "utf8")),
		).not.toHaveProperty("compaction_path");
		await expect(
			service.readSessionCompactionState(sessionId),
		).resolves.toBeUndefined();
	});

	it("adds compaction path to old manifests only when sidecar is written", async () => {
		const sessionsDir = mkdtempSync(join(tmpdir(), "compaction-old-manifest-"));
		tempDirs.push(sessionsDir);
		const service = new FileSessionService(sessionsDir);
		const sessionId = "session-old-manifest";
		const artifacts = await service.createRootSessionWithArtifacts({
			sessionId,
			source: SessionSource.CLI,
			pid: process.pid,
			interactive: true,
			provider: "anthropic",
			model: "claude-sonnet",
			cwd: "/tmp/project",
			workspaceRoot: "/tmp/project",
			enableTools: true,
			enableSpawn: true,
			enableTeams: false,
			startedAt: "2026-01-01T00:00:00.000Z",
		});
		const manifest = JSON.parse(
			readFileSync(artifacts.manifestPath, "utf8"),
		) as {
			compaction_path?: string;
		};
		delete manifest.compaction_path;
		writeFileSync(
			artifacts.manifestPath,
			`${JSON.stringify(manifest, null, 2)}\n`,
			"utf8",
		);
		const state = createSessionCompactionState({
			sourceMessages: [
				{ id: "u1", role: "user" as const, content: "full transcript" },
			],
			compactedMessages: [
				{ id: "summary", role: "user" as const, content: "summary" },
			],
			updatedAt: "2026-01-01T00:00:01.000Z",
		});

		await service.persistSessionCompactionState(sessionId, state);

		expect(existsSync(artifacts.compactionPath ?? "")).toBe(true);
		expect(
			JSON.parse(readFileSync(artifacts.manifestPath, "utf8")),
		).toHaveProperty("compaction_path", artifacts.compactionPath);
	});

	sqliteIt(
		"reconciles dead running sessions into failed manifests with terminal markers",
		async () => {
			const dbDir = mkdtempSync(join(tmpdir(), "stale-session-reconcile-db-"));
			const sessionsDir = mkdtempSync(
				join(tmpdir(), "stale-session-reconcile-sessions-"),
			);
			tempDirs.push(dbDir, sessionsDir);

			const store = new SqliteSessionStore({ sessionsDir: dbDir });
			stores.push(store);
			const service = new CoreSessionService(store, {
				sessionArtifactsDir: sessionsDir,
			});
			const sessionId = "stale-root-session";
			const artifacts = await service.createRootSessionWithArtifacts({
				sessionId,
				source: SessionSource.CLI,
				pid: 999_999_999,
				interactive: false,
				provider: "mock-provider",
				model: "mock-model",
				cwd: "/tmp/project",
				workspaceRoot: "/tmp/project",
				enableTools: true,
				enableSpawn: true,
				enableTeams: false,
				prompt: "hello",
				startedAt: "2026-01-01T00:00:00.000Z",
			});

			const reconciled = await service.reconcileDeadSessions();
			expect(reconciled).toBe(1);

			const rows = await service.listSessions(10);
			expect(rows).toHaveLength(1);
			expect(rows[0]).toMatchObject({
				sessionId,
				status: "failed",
				exitCode: 1,
			});
			expect(rows[0]?.endedAt).toBeTruthy();

			const manifest = JSON.parse(
				readFileSync(artifacts.manifestPath, "utf8"),
			) as Record<string, unknown>;
			expect(manifest.status).toBe("failed");
			expect(manifest.exit_code).toBe(1);
			expect(manifest.ended_at).toBeTruthy();
			expect(manifest.metadata).toMatchObject({
				terminal_marker: "failed_external_process_exit",
				terminal_marker_pid: 999_999_999,
				terminal_marker_source: "stale_session_reconciler",
			});
			expect(
				(manifest.metadata as Record<string, unknown>).terminal_marker_at,
			).toBeTruthy();

			const globalHookLog = process.env.CLINE_HOOKS_LOG_PATH ?? "";
			if (globalHookLog && existsSync(globalHookLog)) {
				const hookContent = readFileSync(globalHookLog, "utf8");
				expect(hookContent).toContain('"hookName":"session_shutdown"');
				expect(hookContent).toContain(
					'"reason":"failed_external_process_exit"',
				);
			}
		},
		15_000,
	);

	sqliteIt(
		"persists teammate task metadata in the file envelope and usage on messages",
		async () => {
			const dbDir = mkdtempSync(join(tmpdir(), "team-task-messages-db-"));
			const sessionsDir = mkdtempSync(join(tmpdir(), "team-task-messages-"));
			tempDirs.push(dbDir, sessionsDir);

			const store = new SqliteSessionStore({ sessionsDir: dbDir });
			stores.push(store);
			const service = new CoreSessionService(store, {
				sessionArtifactsDir: sessionsDir,
			});
			const rootSessionId = "root-session";
			await service.createRootSessionWithArtifacts({
				sessionId: rootSessionId,
				source: SessionSource.CLI,
				pid: process.pid,
				interactive: false,
				provider: "anthropic",
				model: "claude-sonnet-4-6",
				cwd: "/tmp/project",
				workspaceRoot: "/tmp/project",
				enableTools: true,
				enableSpawn: true,
				enableTeams: true,
				prompt: "lead task",
				startedAt: "2026-04-10T19:00:00.000Z",
			});

			await service.onTeamTaskStart(
				rootSessionId,
				"java-haiku-agent",
				"Write a haiku about Java",
			);
			await service.onTeamTaskEnd(
				rootSessionId,
				"java-haiku-agent",
				"completed",
				"[done] completed",
				{
					text: "Classes wrap the world\nWrite once, run on every machine —\nVerbose, yet it soars",
					usage: {
						inputTokens: 42,
						outputTokens: 17,
						cacheReadTokens: 9,
						cacheWriteTokens: 0,
						totalCost: 0.123,
					},
					messages: [
						{
							role: "user",
							content: "Write a haiku about Java. Return only the haiku.",
						},
						{
							role: "assistant",
							content: [
								{
									type: "text",
									text: "Classes wrap the world\nWrite once, run on every machine —\nVerbose, yet it soars",
								},
							],
						},
					],
					toolCalls: [],
					iterations: 1,
					finishReason: "completed",
					model: {
						id: "claude-sonnet-4-6",
						provider: "anthropic",
						info: { id: "claude-sonnet-4-6" },
					},
					startedAt: new Date("2026-04-10T19:00:01.000Z"),
					endedAt: new Date("2026-04-10T19:00:02.000Z"),
					durationMs: 1000,
				},
			);

			const childSessions = await service.listSessions(10);
			const teammateSessionId = childSessions.find((row) =>
				row.sessionId.includes("__teamtask__java-haiku-agent__"),
			)?.sessionId;
			expect(teammateSessionId).toBeTruthy();
			const row = childSessions.find(
				(item) => item.sessionId === teammateSessionId,
			);
			expect(row?.messagesPath).toBeTruthy();
			const path = row?.messagesPath as string;
			const payload = JSON.parse(readFileSync(path, "utf8")) as {
				agent?: string;
				sessionId?: string;
				taskType?: string;
				messages: Array<Record<string, unknown>>;
			};
			const user = payload.messages[0] as Record<string, unknown>;
			const assistant = payload.messages[1] as Record<string, unknown>;

			expect(payload.agent).toBe("teammate");
			expect(payload.sessionId).toBe(rootSessionId);
			expect(payload.taskType).toBe("team");
			expect(assistant.id).toEqual(expect.any(String));
			expect(user.agent).toBeUndefined();
			expect(user.sessionId).toBeUndefined();
			expect(assistant.agent).toBeUndefined();
			expect(assistant.sessionId).toBeUndefined();
			expect(assistant.modelInfo).toMatchObject({
				id: "claude-sonnet-4-6",
				provider: "anthropic",
			});
			expect(assistant.metrics).toMatchObject({
				inputTokens: 42,
				outputTokens: 17,
				cacheReadTokens: 9,
				cacheWriteTokens: 0,
				cost: 0.123,
			});
			expect(row?.messagesPath).toBe(path);
		},
	);

	it("persists plain spawn_agent result usage on child messages", async () => {
		const sessionsDir = mkdtempSync(join(tmpdir(), "spawn-agent-messages-"));
		tempDirs.push(sessionsDir);

		const service = new FileSessionService(sessionsDir);
		const rootSessionId = "root-spawn-session";
		await service.createRootSessionWithArtifacts({
			sessionId: rootSessionId,
			source: SessionSource.CLI,
			pid: process.pid,
			interactive: false,
			provider: "anthropic",
			model: "claude-sonnet-4-6",
			cwd: "/tmp/project",
			workspaceRoot: "/tmp/project",
			enableTools: true,
			enableSpawn: true,
			enableTeams: true,
			prompt: "lead task",
			startedAt: "2026-04-10T19:00:00.000Z",
		});

		const context = {
			subAgentId: "plain-worker",
			conversationId: "conv-plain-worker",
			parentAgentId: "lead",
			input: {
				systemPrompt: "You are a worker.",
				task: "Summarize the repo.",
			},
		};
		await service.handleSubAgentStart(rootSessionId, context);
		await service.handleSubAgentEnd(rootSessionId, {
			...context,
			result: {
				text: "Done",
				iterations: 1,
				finishReason: "completed",
				usage: {
					inputTokens: 11,
					outputTokens: 3,
				},
			},
			agentResult: {
				text: "Done",
				usage: {
					inputTokens: 11,
					outputTokens: 3,
					cacheReadTokens: 4,
					cacheWriteTokens: 2,
					totalCost: 0.045,
				},
				messages: [
					{ role: "user", content: "Summarize the repo." },
					{ role: "assistant", content: "Done" },
				],
				toolCalls: [],
				iterations: 1,
				finishReason: "completed",
				model: {
					id: "claude-sonnet-4-6",
					provider: "anthropic",
					info: { id: "claude-sonnet-4-6" },
				},
				startedAt: new Date("2026-04-10T19:00:01.000Z"),
				endedAt: new Date("2026-04-10T19:00:02.000Z"),
				durationMs: 1000,
			},
		});

		const childSessions = await service.listSessions(10);
		const row = childSessions.find((item) => item.agentId === "plain-worker");
		expect(row?.status).toBe("completed");
		expect(row?.messagesPath).toBeTruthy();
		const payload = JSON.parse(
			readFileSync(row?.messagesPath as string, "utf8"),
		) as {
			messages: Array<Record<string, unknown>>;
		};
		const assistant = payload.messages[1] as Record<string, unknown>;

		expect(assistant.metrics).toMatchObject({
			inputTokens: 11,
			outputTokens: 3,
			cacheReadTokens: 4,
			cacheWriteTokens: 2,
			cost: 0.045,
		});
	});

	it("preserves an existing title when the stored prompt changes", async () => {
		const sessionsDir = mkdtempSync(join(tmpdir(), "prompt-title-sessions-"));
		tempDirs.push(sessionsDir);

		const service = new FileSessionService(sessionsDir);
		const sessionId = "prompt-title-session";
		const artifacts = await service.createRootSessionWithArtifacts({
			sessionId,
			source: SessionSource.CLI,
			pid: process.pid,
			interactive: true,
			provider: "mock-provider",
			model: "mock-model",
			cwd: "/tmp/project",
			workspaceRoot: "/tmp/project",
			enableTools: true,
			enableSpawn: true,
			enableTeams: false,
			prompt: "first user message",
			startedAt: "2026-01-01T00:00:00.000Z",
		});

		await expect(
			service.updateSession({ sessionId, prompt: "second user message" }),
		).resolves.toEqual({ updated: true });

		const [row] = await service.listSessions(10);
		expect(row?.prompt).toBe("second user message");
		expect(row?.metadata).toMatchObject({ title: "first user message" });
		const manifest = JSON.parse(
			readFileSync(artifacts.manifestPath, "utf8"),
		) as Record<string, unknown>;
		expect(manifest.prompt).toBe("second user message");
		expect(manifest.metadata).toMatchObject({ title: "first user message" });
	});

	it("derives a title from a prompt only when the session has no title yet", async () => {
		const sessionsDir = mkdtempSync(join(tmpdir(), "empty-title-sessions-"));
		tempDirs.push(sessionsDir);

		const service = new FileSessionService(sessionsDir);
		const sessionId = "empty-title-session";
		await service.createRootSessionWithArtifacts({
			sessionId,
			source: SessionSource.CLI,
			pid: process.pid,
			interactive: true,
			provider: "mock-provider",
			model: "mock-model",
			cwd: "/tmp/project",
			workspaceRoot: "/tmp/project",
			enableTools: true,
			enableSpawn: true,
			enableTeams: false,
			startedAt: "2026-01-01T00:00:00.000Z",
		});

		await expect(
			service.updateSession({ sessionId, prompt: "first saved prompt" }),
		).resolves.toEqual({ updated: true });

		const [row] = await service.listSessions(10);
		expect(row?.metadata).toMatchObject({ title: "first saved prompt" });
	});

	// ── FORK BUGFIX (keypool-live): checkpoint-runcount-fix ──────────────────
	// See .backport-agent/customizations.yaml id "checkpoint-runcount-fix".
	it("mergeSessionMetadata re-applies the resolver against fresh state on every OCC retry", async () => {
		const sessionsDir = mkdtempSync(join(tmpdir(), "merge-metadata-race-"));
		tempDirs.push(sessionsDir);

		let statusLock = 0;
		let metadata: Record<string, unknown> | undefined = { existing: "value" };
		let updateSessionCalls = 0;

		const fakeAdapter: SessionPersistenceAdapter = {
			ensureSessionsDir: () => sessionsDir,
			upsertSession: async () => {},
			getSession: async (sessionId) => ({
				sessionId,
				source: "cli",
				pid: 1,
				startedAt: "2026-01-01T00:00:00.000Z",
				endedAt: null,
				exitCode: null,
				status: "running",
				statusLock,
				interactive: true,
				provider: "mock",
				model: "mock",
				cwd: "/tmp/project",
				workspaceRoot: "/tmp/project",
				teamName: null,
				enableTools: true,
				enableSpawn: true,
				enableTeams: false,
				parentSessionId: null,
				parentAgentId: null,
				agentId: null,
				conversationId: null,
				isSubagent: false,
				prompt: null,
				metadata,
				hookPath: "",
				messagesPath: null,
				updatedAt: "2026-01-01T00:00:00.000Z",
			}),
			listSessions: async () => [],
			updateSession: async (input) => {
				updateSessionCalls += 1;
				if (updateSessionCalls === 1) {
					// Simulate a concurrent writer (e.g. a usage/cost update for
					// the same turn) committing between our read and our write.
					statusLock += 1;
					metadata = { ...metadata, concurrentWrite: true };
					return { updated: false, statusLock };
				}
				if (input.expectedStatusLock !== statusLock) {
					return { updated: false, statusLock };
				}
				statusLock += 1;
				metadata = (input.metadata ?? undefined) as
					| Record<string, unknown>
					| undefined;
				return { updated: true, statusLock };
			},
			deleteSession: async () => true,
			enqueueSpawnRequest: async () => {},
			claimSpawnRequest: async () => undefined,
		};

		const service = new UnifiedSessionPersistenceService(fakeAdapter);

		const result = await service.mergeSessionMetadata("sess-race", (current) => ({
			...(current ?? {}),
			ourCheckpoint: "run-1",
		}));

		expect(updateSessionCalls).toBe(2);
		expect(result).toEqual({
			updated: true,
			metadata: {
				existing: "value",
				concurrentWrite: true,
				ourCheckpoint: "run-1",
			},
		});
	});

	sqliteIt(
		"uploads messages after persisting them when a messages uploader is configured",
		async () => {
			const dbDir = mkdtempSync(join(tmpdir(), "messages-upload-db-"));
			const sessionsDir = mkdtempSync(join(tmpdir(), "messages-upload-"));
			tempDirs.push(dbDir, sessionsDir);

			const store = new SqliteSessionStore({ sessionsDir: dbDir });
			stores.push(store);
			const uploadMessagesFile = vi.fn(async () => {});
			const service = new CoreSessionService(store, {
				sessionArtifactsDir: sessionsDir,
				messagesArtifactUploader: {
					uploadMessagesFile,
				},
			});
			const sessionId = "root-upload-session";
			await service.createRootSessionWithArtifacts({
				sessionId,
				source: SessionSource.CLI,
				pid: process.pid,
				interactive: false,
				provider: "anthropic",
				model: "claude-sonnet-4-6",
				cwd: "/tmp/project",
				workspaceRoot: "/tmp/project",
				enableTools: true,
				enableSpawn: false,
				enableTeams: false,
				prompt: "hello",
				metadata: {
					blobUpload: true,
				},
				startedAt: "2026-04-10T19:00:00.000Z",
			});

			await service.persistSessionMessages(sessionId, [
				{
					role: "user",
					content: "hello",
				},
			]);

			expect(uploadMessagesFile).toHaveBeenCalledTimes(1);
			expect(uploadMessagesFile).toHaveBeenCalledWith(
				expect.objectContaining({
					sessionId,
					path: expect.stringContaining(`${sessionId}.messages.json`),
					contents: expect.stringContaining('"role": "user"'),
					row: expect.objectContaining({
						sessionId,
						metadata: {
							blobUpload: true,
							title: "hello",
						},
					}),
				}),
			);
		},
	);

	sqliteIt(
		"keeps failed message uploads out of user-facing console output",
		async () => {
			const dbDir = mkdtempSync(join(tmpdir(), "messages-upload-fail-db-"));
			const sessionsDir = mkdtempSync(join(tmpdir(), "messages-upload-fail-"));
			tempDirs.push(dbDir, sessionsDir);

			const store = new SqliteSessionStore({ sessionsDir: dbDir });
			stores.push(store);
			const uploadError = new Error("upload denied");
			const uploadMessagesFile = vi.fn(async () => {
				throw uploadError;
			});
			const logger = {
				debug: vi.fn(),
				log: vi.fn(),
			};
			const warn = vi.spyOn(console, "warn").mockImplementation(() => {});
			const service = new CoreSessionService(store, {
				sessionArtifactsDir: sessionsDir,
				messagesArtifactUploader: {
					uploadMessagesFile,
				},
				logger,
			});
			const sessionId = "root-upload-fail-session";
			await service.createRootSessionWithArtifacts({
				sessionId,
				source: SessionSource.CLI,
				pid: process.pid,
				interactive: false,
				provider: "openrouter",
				model: "qwen/qwen3.6-plus",
				cwd: "/tmp/project",
				workspaceRoot: "/tmp/project",
				enableTools: true,
				enableSpawn: false,
				enableTeams: false,
				prompt: "hello",
				startedAt: "2026-04-10T19:00:00.000Z",
			});

			try {
				await expect(
					service.persistSessionMessages(sessionId, [
						{
							role: "user",
							content: "hello",
						},
					]),
				).resolves.toBeUndefined();
				expect(warn).not.toHaveBeenCalled();
			} finally {
				warn.mockRestore();
			}

			expect(uploadMessagesFile).toHaveBeenCalledTimes(1);
			expect(logger.debug).toHaveBeenCalledWith(
				"Failed to upload persisted session messages",
				{
					sessionId,
					error: uploadError,
				},
			);
		},
	);

	sqliteIt(
		"deletes the full root session directory even when artifact paths are stale",
		async () => {
			const dbDir = mkdtempSync(join(tmpdir(), "delete-root-session-dir-db-"));
			const sessionsDir = mkdtempSync(
				join(tmpdir(), "delete-root-session-dir-"),
			);
			tempDirs.push(dbDir, sessionsDir);

			const store = new SqliteSessionStore({ sessionsDir: dbDir });
			stores.push(store);
			const service = new CoreSessionService(store, {
				sessionArtifactsDir: sessionsDir,
			});
			const sessionId = "root-session-delete";
			const artifacts = await service.createRootSessionWithArtifacts({
				sessionId,
				source: SessionSource.CLI,
				pid: process.pid,
				interactive: false,
				provider: "anthropic",
				model: "claude-sonnet-4-6",
				cwd: "/tmp/project",
				workspaceRoot: "/tmp/project",
				enableTools: true,
				enableSpawn: false,
				enableTeams: false,
				prompt: "delete me",
				startedAt: "2026-04-10T19:00:00.000Z",
			});

			store.run(
				`UPDATE sessions SET messages_path = NULL WHERE session_id = ?`,
				[sessionId],
			);

			expect(existsSync(artifacts.messagesPath)).toBe(true);
			expect(existsSync(join(sessionsDir, sessionId))).toBe(true);

			const result = await service.deleteSession(sessionId);

			expect(result).toEqual({ deleted: true });
			expect(existsSync(artifacts.messagesPath)).toBe(false);
			expect(existsSync(join(sessionsDir, sessionId))).toBe(false);
		},
	);

	sqliteIt(
		"deletes a session when compaction sidecar cleanup fails",
		async () => {
			const dbDir = mkdtempSync(join(tmpdir(), "delete-sidecar-fail-db-"));
			const sessionsDir = mkdtempSync(
				join(tmpdir(), "delete-sidecar-fail-sessions-"),
			);
			tempDirs.push(dbDir, sessionsDir);

			const store = new SqliteSessionStore({ sessionsDir: dbDir });
			stores.push(store);
			const service = new CoreSessionService(store, {
				sessionArtifactsDir: sessionsDir,
			});
			const sessionId = "sidecar-delete-fail-session";
			await service.createRootSessionWithArtifacts({
				sessionId,
				source: SessionSource.CLI,
				pid: process.pid,
				interactive: false,
				provider: "anthropic",
				model: "claude-sonnet-4-6",
				cwd: "/tmp/project",
				workspaceRoot: "/tmp/project",
				enableTools: true,
				enableSpawn: false,
				enableTeams: false,
				prompt: "delete me",
				startedAt: "2026-04-10T19:00:00.000Z",
			});
			const manifestStore = (
				service as unknown as {
					manifestStore: {
						deleteSessionCompactionState: (sessionId: string) => Promise<void>;
					};
				}
			).manifestStore;
			const deleteSidecar = vi
				.spyOn(manifestStore, "deleteSessionCompactionState")
				.mockRejectedValue(new Error("sidecar busy"));

			const result = await service.deleteSession(sessionId);

			expect(result).toEqual({ deleted: true });
			await expect(service.listSessions(10)).resolves.not.toEqual(
				expect.arrayContaining([expect.objectContaining({ sessionId })]),
			);
			expect(deleteSidecar).toHaveBeenCalledWith(sessionId);
		},
	);
});
