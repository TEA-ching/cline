import type * as LlmsProviders from "@sctg/cline-llms";
import type {
	ChatRunTurnRequest,
	ChatStartSessionRequest,
	ChatStartSessionResponse,
	ChatTurnResult,
	HubEventEnvelope,
	TeamProgressProjectionEvent,
} from "@sctg/cline-shared";
import type { CheckpointEntry } from "../../hooks/checkpoint-hooks";
import { isSessionNotFoundError } from "../../runtime/host/runtime-host";
import { NodeHubClient } from "../client";

type ScheduleClientRecord = Record<string, unknown> & {
	metadata?: Record<string, unknown>;
};

export interface HubSessionClientOptions {
	address: string;
	authToken?: string;
	clientId?: string;
	clientType?: string;
	displayName?: string;
	workspaceRoot?: string;
	cwd?: string;
	metadata?: Record<string, unknown>;
}

export interface HubSessionRow {
	sessionId: string;
	parentSessionId?: string;
	metadata?: Record<string, unknown>;
	messagesPath?: string;
}

export interface HubStreamEvent {
	sessionId: string;
	eventType: string;
	payload: Record<string, unknown>;
}

export interface HubRestoreRequest {
	sessionId: string;
	checkpointRunCount: number;
	config?: ChatStartSessionRequest;
	restore?: {
		messages?: boolean;
		workspace?: boolean;
		omitCheckpointMessageFromSession?: boolean;
	};
}

export interface HubRestoreResponse {
	sessionId?: string;
	startResult?: {
		sessionId: string;
		manifestPath: string;
		messagesPath: string;
	};
	messages?: LlmsProviders.Message[];
	checkpoint: CheckpointEntry;
}

export interface HubEventStreamHandlers {
	onEvent?: (event: HubStreamEvent) => void;
	onError?: (error: Error) => void;
}

export interface HubTeamProgressHandlers {
	onProjection?: (event: TeamProgressProjectionEvent) => void;
	onError?: (error: Error) => void;
}

function cloneRecord(
	value: Record<string, unknown> | undefined,
): Record<string, unknown> {
	return value ? JSON.parse(JSON.stringify(value)) : {};
}

function extractSessionRow(
	payload: Record<string, unknown> | undefined,
): HubSessionRow | undefined {
	const session =
		payload?.session && typeof payload.session === "object"
			? (payload.session as Record<string, unknown>)
			: undefined;
	if (!session) {
		return undefined;
	}
	const metadata =
		session.metadata && typeof session.metadata === "object"
			? cloneRecord(session.metadata as Record<string, unknown>)
			: undefined;
	return {
		sessionId: typeof session.sessionId === "string" ? session.sessionId : "",
		parentSessionId:
			typeof metadata?.parentSessionId === "string"
				? metadata.parentSessionId
				: undefined,
		messagesPath:
			typeof metadata?.messagesPath === "string"
				? metadata.messagesPath
				: undefined,
		metadata,
	};
}

function hubReplyErrorMessage(
	reply: { error?: { message?: string } },
	command: string,
): string {
	return reply.error?.message ?? `hub command failed: ${command}`;
}

function normalizeFailedRunPayload(
	payload: Record<string, unknown> | undefined,
): Record<string, unknown> {
	const cloned = cloneRecord(payload);
	if (typeof cloned.error === "string" && cloned.error.trim()) {
		return { ...cloned, error: cloned.error.trim() };
	}
	const result =
		cloned.result && typeof cloned.result === "object"
			? (cloned.result as Record<string, unknown>)
			: undefined;
	if (typeof result?.text === "string" && result.text.trim()) {
		return { ...cloned, error: result.text.trim() };
	}
	const resultError =
		result?.error && typeof result.error === "object"
			? (result.error as Record<string, unknown>)
			: undefined;
	if (typeof resultError?.message === "string" && resultError.message.trim()) {
		return { ...cloned, error: resultError.message.trim() };
	}
	return cloned;
}

function payloadSessionId(
	payload: Record<string, unknown> | undefined,
): string | undefined {
	const value = payload?.sessionId;
	return typeof value === "string" && value.trim() ? value.trim() : undefined;
}

function extractCheckpoint(
	payload: Record<string, unknown> | undefined,
): CheckpointEntry {
	const checkpoint = payload?.checkpoint;
	if (
		!checkpoint ||
		typeof checkpoint !== "object" ||
		Array.isArray(checkpoint)
	) {
		throw new Error("hub checkpoint restore returned no checkpoint");
	}
	const record = checkpoint as Partial<CheckpointEntry>;
	if (
		typeof record.ref !== "string" ||
		typeof record.createdAt !== "number" ||
		typeof record.runCount !== "number"
	) {
		throw new Error("hub checkpoint restore returned an invalid checkpoint");
	}
	return record as CheckpointEntry;
}

function mapHubEvent(event: HubEventEnvelope): HubStreamEvent | undefined {
	const payload = cloneRecord(event.payload);
	if (event.event === "schedule.execution_completed") {
		return {
			sessionId: event.sessionId?.trim() || payloadSessionId(payload) || "",
			eventType: "schedule.execution.completed",
			payload,
		};
	}
	if (event.event === "schedule.execution_failed") {
		return {
			sessionId: event.sessionId?.trim() || payloadSessionId(payload) || "",
			eventType: "schedule.execution.failed",
			payload,
		};
	}

	const sessionId = event.sessionId?.trim();
	if (!sessionId) {
		return undefined;
	}
	switch (event.event) {
		case "iteration.started":
			return {
				sessionId,
				eventType: "runtime.chat.iteration_start",
				payload,
			};
		case "iteration.finished":
			return {
				sessionId,
				eventType: "runtime.chat.iteration_end",
				payload,
			};
		case "assistant.delta":
			return {
				sessionId,
				eventType: "runtime.chat.text_delta",
				payload,
			};
		case "usage.updated":
			return {
				sessionId,
				eventType: "runtime.chat.usage",
				payload,
			};
		case "session.notice":
			return {
				sessionId,
				eventType: "runtime.chat.notice",
				payload,
			};
		case "tool.started":
			return {
				sessionId,
				eventType: "runtime.chat.tool_call_start",
				payload,
			};
		case "tool.finished":
			return {
				sessionId,
				eventType: "runtime.chat.tool_call_end",
				payload,
			};
		case "approval.requested":
			return {
				sessionId,
				eventType: "approval.requested",
				payload,
			};
		case "run.aborted":
			return {
				sessionId,
				eventType: "runtime.chat.aborted",
				payload,
			};
		case "run.failed":
			return {
				sessionId,
				eventType: "runtime.chat.failed",
				payload: normalizeFailedRunPayload(event.payload),
			};
		case "run.completed":
			return {
				sessionId,
				eventType: "runtime.chat.completed",
				payload,
			};
		default:
			return undefined;
	}
}

export class HubSessionClient {
	private readonly client: NodeHubClient;
	private metadataApplied = false;

	constructor(private readonly options: HubSessionClientOptions) {
		this.client = new NodeHubClient({
			url: options.address,
			authToken: options.authToken,
			clientId: options.clientId,
			clientType: options.clientType ?? "hub-session-client",
			displayName: options.displayName ?? "hub session client",
			workspaceRoot: options.workspaceRoot,
			cwd: options.cwd,
		});
	}

	private async ensureMetadataApplied(): Promise<void> {
		if (this.metadataApplied || !this.options.metadata) {
			if (!this.options.metadata) {
				await this.client.connect();
			}
			return;
		}
		await this.client.connect();
		await this.client.command("client.update", {
			metadata: this.options.metadata,
		});
		this.metadataApplied = true;
	}

	async connect(): Promise<void> {
		await this.ensureMetadataApplied();
	}

	close(): void {
		this.client.close();
	}

	async dispose(): Promise<void> {
		await this.client.dispose();
	}

	async startRuntimeSession(
		request: ChatStartSessionRequest,
	): Promise<ChatStartSessionResponse> {
		await this.ensureMetadataApplied();
		const reply = await this.client.command("session.create", {
			workspaceRoot: request.workspaceRoot,
			cwd: request.cwd,
			sessionConfig: {
				providerId: request.provider,
				modelId: request.model,
				apiKey: request.apiKey,
				cwd: request.cwd ?? request.workspaceRoot,
				workspaceRoot: request.workspaceRoot,
				systemPrompt: request.systemPrompt ?? "",
				mode: request.mode ?? "act",
				rules: request.rules,
				maxIterations: request.maxIterations,
				timeoutSeconds: request.timeoutSeconds,
				enableTools: request.enableTools,
				enableSpawnAgent: request.enableSpawn !== false,
				enableAgentTeams: request.enableTeams !== false,
				disableMcpSettingsTools: request.disableMcpSettingsTools,
				missionLogIntervalSteps: request.missionStepInterval,
				missionLogIntervalMs: request.missionTimeIntervalMs,
			},
			metadata: {
				source: request.source ?? "cli",
				provider: request.provider,
				model: request.model,
				enableTools: request.enableTools,
				enableSpawn: request.enableSpawn,
				enableTeams: request.enableTeams,
				prompt: undefined,
				interactive: request.interactive !== false,
			},
			runtimeOptions: {
				mode: request.mode,
				systemPrompt: request.systemPrompt,
				maxIterations: request.maxIterations,
				timeoutSeconds: request.timeoutSeconds,
				enableTools: request.enableTools,
				enableSpawn: request.enableSpawn,
				enableTeams: request.enableTeams,
				autoApproveTools: request.autoApproveTools,
				toolExecutors: request.toolExecutors,
				configExtensions: request.configExtensions,
			},
			modelSelection: {
				provider: request.provider,
				model: request.model,
				apiKey: request.apiKey,
			},
			toolPolicies: request.toolPolicies,
		});
		const row = extractSessionRow(reply.payload);
		if (!row?.sessionId) {
			throw new Error("hub session create returned no session id");
		}
		return {
			sessionId: row.sessionId,
			startResult: {
				sessionId: row.sessionId,
				manifestPath: "",
				messagesPath: row.messagesPath ?? "",
			},
		};
	}

	async sendRuntimeSession(
		sessionId: string,
		request: ChatRunTurnRequest,
		options?: { timeoutMs?: number | null },
	): Promise<{ result?: ChatTurnResult }> {
		await this.ensureMetadataApplied();
		const reply = await this.client.command(
			"session.send_input",
			{
				prompt: request.prompt,
				mode: request.config.mode,
				attachments: request.attachments,
				delivery: request.delivery,
				timeoutSeconds: request.config.timeoutSeconds,
			},
			sessionId,
			options,
		);
		return {
			result: reply.payload?.result as ChatTurnResult | undefined,
		};
	}

	async stopRuntimeSession(sessionId: string): Promise<{ applied: boolean }> {
		await this.ensureMetadataApplied();
		await this.client.command("session.detach", { sessionId }, sessionId);
		return { applied: true };
	}

	async abortRuntimeSession(sessionId: string): Promise<{ applied: boolean }> {
		await this.ensureMetadataApplied();
		await this.client.command("run.abort", { sessionId }, sessionId);
		return { applied: true };
	}

	async updateSession(input: {
		sessionId: string;
		metadata?: Record<string, unknown>;
	}): Promise<{ updated: boolean }> {
		await this.ensureMetadataApplied();
		await this.client.command(
			"session.update",
			{
				sessionId: input.sessionId,
				metadata: input.metadata,
			},
			input.sessionId,
		);
		return { updated: true };
	}

	async getSession(sessionId: string): Promise<HubSessionRow | undefined> {
		await this.ensureMetadataApplied();
		let reply: Awaited<ReturnType<NodeHubClient["command"]>>;
		try {
			reply = await this.client.command("session.get", undefined, sessionId);
		} catch (error) {
			if (isSessionNotFoundError(error)) {
				return undefined;
			}
			throw error;
		}
		return extractSessionRow(reply.payload);
	}

	async readMessages(sessionId: string): Promise<LlmsProviders.Message[]> {
		const target = sessionId.trim();
		if (!target) {
			return [];
		}
		await this.ensureMetadataApplied();
		const reply = await this.client.command(
			"session.messages",
			{ sessionId: target },
			target,
		);
		if (!reply.ok) {
			throw new Error(hubReplyErrorMessage(reply, "session.messages"));
		}
		const messages = reply.payload?.messages;
		return Array.isArray(messages) ? (messages as LlmsProviders.Message[]) : [];
	}

	async restore(input: HubRestoreRequest): Promise<HubRestoreResponse> {
		const sessionId = input.sessionId.trim();
		if (!sessionId) {
			throw new Error("sessionId is required");
		}
		const restoreMessages = input.restore?.messages !== false;
		if (restoreMessages && !input.config) {
			throw new Error("config is required when restore.messages is true");
		}
		await this.ensureMetadataApplied();
		const request = input.config;
		const reply = await this.client.command(
			"session.restore",
			{
				sessionId,
				checkpointRunCount: input.checkpointRunCount,
				restore: input.restore,
				...(request
					? {
							workspaceRoot: request.workspaceRoot,
							cwd: request.cwd,
							sessionConfig: {
								providerId: request.provider,
								modelId: request.model,
								apiKey: request.apiKey,
								cwd: request.cwd ?? request.workspaceRoot,
								workspaceRoot: request.workspaceRoot,
								systemPrompt: request.systemPrompt ?? "",
								mode: request.mode ?? "act",
								rules: request.rules,
								maxIterations: request.maxIterations,
								enableTools: request.enableTools,
								enableSpawnAgent: request.enableSpawn !== false,
								enableAgentTeams: request.enableTeams !== false,
								disableMcpSettingsTools: request.disableMcpSettingsTools,
								missionLogIntervalSteps: request.missionStepInterval,
								missionLogIntervalMs: request.missionTimeIntervalMs,
							},
							metadata: {
								source: request.source ?? "cli",
								provider: request.provider,
								model: request.model,
								enableTools: request.enableTools,
								enableSpawn: request.enableSpawn,
								enableTeams: request.enableTeams,
								prompt: undefined,
								interactive: request.interactive !== false,
							},
							runtimeOptions: {
								mode: request.mode,
								systemPrompt: request.systemPrompt,
								maxIterations: request.maxIterations,
								enableTools: request.enableTools,
								enableSpawn: request.enableSpawn,
								enableTeams: request.enableTeams,
								autoApproveTools: request.autoApproveTools,
								configExtensions: request.configExtensions,
							},
							modelSelection: {
								provider: request.provider,
								model: request.model,
								apiKey: request.apiKey,
							},
							toolPolicies: request.toolPolicies,
						}
					: {}),
			},
			sessionId,
		);
		if (!reply.ok) {
			throw new Error(hubReplyErrorMessage(reply, "session.restore"));
		}
		const row = extractSessionRow(reply.payload);
		if (restoreMessages && !row?.sessionId) {
			throw new Error("hub checkpoint restore returned no session id");
		}
		const messages = Array.isArray(reply.payload?.messages)
			? (reply.payload.messages as LlmsProviders.Message[])
			: undefined;
		const checkpoint = extractCheckpoint(reply.payload);
		return {
			sessionId: row?.sessionId,
			startResult: row?.sessionId
				? {
						sessionId: row.sessionId,
						manifestPath: "",
						messagesPath: row.messagesPath ?? "",
					}
				: undefined,
			...(messages ? { messages } : {}),
			checkpoint,
		};
	}

	async listSessions(input?: { limit?: number }): Promise<HubSessionRow[]> {
		await this.ensureMetadataApplied();
		const reply = await this.client.command("session.list", {
			limit: input?.limit ?? 200,
		});
		const sessions = Array.isArray(reply.payload?.sessions)
			? (reply.payload?.sessions as Record<string, unknown>[])
			: [];
		return sessions
			.map((session) => extractSessionRow({ session }))
			.filter((row): row is HubSessionRow => Boolean(row?.sessionId));
	}

	async deleteSession(
		sessionId: string,
		deleteCheckpointRefs = true,
	): Promise<boolean> {
		await this.ensureMetadataApplied();
		const reply = await this.client.command("session.delete", {
			sessionId,
			deleteCheckpointRefs,
		});
		return reply.payload?.deleted === true;
	}

	async respondToolApproval(input: {
		approvalId: string;
		approved: boolean;
		reason?: string;
		responderClientId?: string;
	}): Promise<void> {
		await this.ensureMetadataApplied();
		await this.client.command("approval.respond", {
			approvalId: input.approvalId,
			approved: input.approved,
			payload: input.reason ? { reason: input.reason } : undefined,
			responderClientId: input.responderClientId,
		});
	}

	streamEvents(
		input: { clientId?: string; sessionIds?: string[] },
		handlers: HubEventStreamHandlers,
	): () => void {
		const allowed = new Set(
			(input.sessionIds ?? []).map((id) => id.trim()).filter(Boolean),
		);
		const unsubscribe = this.client.subscribe((event: HubEventEnvelope) => {
			const mapped = mapHubEvent(event);
			if (!mapped) {
				return;
			}
			if (allowed.size > 0 && !allowed.has(mapped.sessionId)) {
				return;
			}
			handlers.onEvent?.(mapped);
		});
		void this.ensureMetadataApplied().catch((error) => {
			handlers.onError?.(
				error instanceof Error ? error : new Error(String(error)),
			);
		});
		return unsubscribe;
	}

	streamTeamProgress(
		_input: { clientId?: string },
		handlers: HubTeamProgressHandlers,
	): () => void {
		const unsubscribe = this.client.subscribe((event: HubEventEnvelope) => {
			if (event.event !== "team.progress" || !event.payload) {
				return;
			}
			handlers.onProjection?.(
				event.payload as unknown as TeamProgressProjectionEvent,
			);
		});
		void this.ensureMetadataApplied().catch((error) => {
			handlers.onError?.(
				error instanceof Error ? error : new Error(String(error)),
			);
		});
		return unsubscribe;
	}

	async createSchedule(
		input: Record<string, unknown>,
	): Promise<ScheduleClientRecord | undefined> {
		await this.ensureMetadataApplied();
		const reply = await this.client.command("schedule.create", input);
		return reply.payload?.schedule as ScheduleClientRecord | undefined;
	}

	async listSchedules(_input?: {
		limit?: number;
	}): Promise<ScheduleClientRecord[]> {
		await this.ensureMetadataApplied();
		const reply = await this.client.command("schedule.list");
		return Array.isArray(reply.payload?.schedules)
			? (reply.payload?.schedules as ScheduleClientRecord[])
			: [];
	}

	async getSchedule(
		scheduleId: string,
	): Promise<ScheduleClientRecord | undefined> {
		await this.ensureMetadataApplied();
		const reply = await this.client.command("schedule.get", { scheduleId });
		return reply.payload?.schedule as ScheduleClientRecord | undefined;
	}

	async updateSchedule(
		scheduleId: string,
		input: Record<string, unknown>,
	): Promise<ScheduleClientRecord | undefined> {
		await this.ensureMetadataApplied();
		const reply = await this.client.command("schedule.update", {
			scheduleId,
			...input,
		});
		return reply.payload?.schedule as ScheduleClientRecord | undefined;
	}

	async pauseSchedule(
		scheduleId: string,
	): Promise<ScheduleClientRecord | undefined> {
		await this.ensureMetadataApplied();
		const reply = await this.client.command("schedule.disable", { scheduleId });
		return reply.payload?.schedule as ScheduleClientRecord | undefined;
	}

	async resumeSchedule(
		scheduleId: string,
	): Promise<ScheduleClientRecord | undefined> {
		await this.ensureMetadataApplied();
		const reply = await this.client.command("schedule.enable", { scheduleId });
		return reply.payload?.schedule as ScheduleClientRecord | undefined;
	}

	async deleteSchedule(scheduleId: string): Promise<boolean> {
		await this.ensureMetadataApplied();
		const reply = await this.client.command("schedule.delete", { scheduleId });
		return reply.payload?.deleted === true;
	}

	async triggerScheduleNow(
		scheduleId: string,
	): Promise<Record<string, unknown> | undefined> {
		await this.ensureMetadataApplied();
		const reply = await this.client.command("schedule.trigger", { scheduleId });
		return reply.payload?.execution as Record<string, unknown> | undefined;
	}

	async listScheduleExecutions(
		scheduleId: string,
		limit?: number,
	): Promise<Array<Record<string, unknown>>> {
		await this.ensureMetadataApplied();
		const reply = await this.client.command("schedule.list_executions", {
			scheduleId,
			limit,
		});
		return Array.isArray(reply.payload?.executions)
			? (reply.payload?.executions as Array<Record<string, unknown>>)
			: [];
	}

	async getScheduleStats(): Promise<Record<string, unknown> | undefined> {
		await this.ensureMetadataApplied();
		const reply = await this.client.command("schedule.stats");
		return reply.payload?.stats as Record<string, unknown> | undefined;
	}

	async getActiveScheduledExecutions(): Promise<
		Array<Record<string, unknown>>
	> {
		await this.ensureMetadataApplied();
		const reply = await this.client.command("schedule.active");
		return Array.isArray(reply.payload?.executions)
			? (reply.payload?.executions as Array<Record<string, unknown>>)
			: [];
	}

	async getUpcomingScheduledRuns(
		limit?: number,
	): Promise<Array<Record<string, unknown>>> {
		await this.ensureMetadataApplied();
		const reply = await this.client.command("schedule.upcoming", { limit });
		return Array.isArray(reply.payload?.upcoming)
			? (reply.payload?.upcoming as Array<Record<string, unknown>>)
			: [];
	}
}
