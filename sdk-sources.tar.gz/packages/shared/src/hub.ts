import type { AgentMessage } from "./agent";
import type { ReasoningEffort } from "./agents/types";
import type { GatewayModelSelection, JsonValue } from "./llms/gateway";
import type { RuntimeConfigExtensionKind } from "./session/runtime-config";

export type HubProtocolVersion = "v1";

export const CURRENT_HUB_PROTOCOL_VERSION: HubProtocolVersion = "v1";
export const MIN_CLIENT_HUB_PROTOCOL_VERSION: HubProtocolVersion = "v1";
export const MAX_CLIENT_HUB_PROTOCOL_VERSION: HubProtocolVersion = "v1";

export type HubCapabilityName =
	| "client.register"
	| "client.list"
	| "session.create"
	| "session.list"
	| "session.get"
	| "session.run"
	| "session.abort"
	| "schedule.create"
	| "schedule.list"
	| "settings.get"
	| "settings.set";

export const HUB_CAPABILITIES: readonly HubCapabilityName[] = [
	"client.register",
	"client.list",
	"session.create",
	"session.list",
	"session.get",
	"session.run",
	"session.abort",
	"schedule.create",
	"schedule.list",
	"settings.get",
	"settings.set",
];

export interface HubProtocolMetadata {
	protocolVersion: string;
	minClientProtocolVersion?: string;
	maxClientProtocolVersion?: string;
	capabilities?: readonly string[];
}

export type HubCompatibilityResult =
	| { compatible: true }
	| { compatible: false; reason: "missing_protocol" | "unsupported_protocol" };

function parseHubProtocolNumber(
	version: string | undefined,
): number | undefined {
	const match = /^v(\d+)$/.exec(version?.trim() ?? "");
	if (!match) {
		return undefined;
	}
	return Number.parseInt(match[1] ?? "", 10);
}

export function isHubProtocolCompatible(
	hub: HubProtocolMetadata,
	clientProtocolVersion: HubProtocolVersion = CURRENT_HUB_PROTOCOL_VERSION,
): HubCompatibilityResult {
	const hubProtocol = parseHubProtocolNumber(hub.protocolVersion);
	const clientProtocol = parseHubProtocolNumber(clientProtocolVersion);
	if (hubProtocol === undefined || clientProtocol === undefined) {
		return { compatible: false, reason: "missing_protocol" };
	}
	const minClientProtocol =
		parseHubProtocolNumber(hub.minClientProtocolVersion) ?? hubProtocol;
	const maxClientProtocol =
		parseHubProtocolNumber(hub.maxClientProtocolVersion) ?? hubProtocol;
	return clientProtocol >= minClientProtocol &&
		clientProtocol <= maxClientProtocol
		? { compatible: true }
		: { compatible: false, reason: "unsupported_protocol" };
}

export type HubActorKind = "client" | "peerHub";

export type HubTransportKind =
	| "native"
	| "browser"
	| "remote"
	| "native-grpc"
	| "browser-ws"
	| "browser-grpc-web"
	| "peer-grpc";

export type HubRuntimeStatus =
	| "idle"
	| "running"
	| "pending"
	| "completed"
	| "aborted"
	| "failed";

export type HubSpokeStatus =
	| "starting"
	| "ready"
	| "busy"
	| "stopping"
	| "stopped"
	| "failed";

export interface ClientCapability {
	name: string;
	description?: string;
	scopes?: string[];
	payloadSchema?: Record<string, unknown>;
}

export interface HubClientRegistration {
	clientId?: string;
	clientType: string;
	displayName?: string;
	actorKind?: HubActorKind;
	transport: HubTransportKind;
	capabilities?: ClientCapability[];
	metadata?: Record<string, JsonValue | undefined>;
	workspaceContext?: {
		workspaceRoot?: string;
		cwd?: string;
	};
	protocolVersion?: HubProtocolVersion;
}

export interface HubClientRecord {
	clientId: string;
	clientType: string;
	displayName?: string;
	actorKind: HubActorKind;
	connectedAt: number;
	lastSeenAt: number;
	transport: HubTransportKind;
	capabilities: ClientCapability[];
	metadata?: Record<string, JsonValue | undefined>;
	workspaceContext?: {
		workspaceRoot?: string;
		cwd?: string;
	};
}

export interface SessionParticipant {
	clientId: string;
	attachedAt: number;
	role?: "creator" | "participant" | "observer";
	metadata?: Record<string, JsonValue | undefined>;
}

export interface SessionMetrics {
	inputTokens?: number;
	outputTokens?: number;
	cacheReadTokens?: number;
	cacheWriteTokens?: number;
	totalCost?: number;
}

export interface HubTeamMembership {
	teamId: string;
	role?: "lead" | "teammate" | "contractor";
}

export interface HubSessionRuntimeSnapshot {
	runId?: string;
	status?: HubRuntimeStatus;
	iteration?: number;
	messages?: AgentMessage[];
	pendingToolCalls?: unknown[];
	usage?: SessionMetrics;
	aggregateUsage?: SessionMetrics;
	lastError?: string;
}

export interface SessionRecord {
	sessionId: string;
	workspaceRoot: string;
	cwd?: string;
	createdAt: number;
	updatedAt: number;
	createdByClientId: string;
	assignedSpokeId?: string;
	status: HubRuntimeStatus;
	/**
	 * Clients currently observing or attached to this session. Participants do not
	 * own client-local capabilities; capability routing is owned by the client that
	 * created/restored the runtime session and advertised those capabilities.
	 */
	participants: SessionParticipant[];
	activeRunId?: string;
	runtimeOptions?: HubSessionRuntimeOptions;
	metadata?: Record<string, JsonValue | undefined>;
	runtimeSession?: {
		agentId: string;
		agentRole?: string;
		team?: HubTeamMembership;
	};
	usage?: SessionMetrics;
	aggregateUsage?: SessionMetrics;
}

export interface HubSessionSnapshot {
	sessionId: string;
	agentId: string;
	agentRole?: string;
	workspacePath: string;
	rootPath?: string;
	createdAt: number;
	updatedAt: number;
	messages: AgentMessage[];
	runCount: number;
	lastRunId?: string;
	status: HubRuntimeStatus;
	metadata?: Record<string, unknown>;
	team?: HubTeamMembership;
	runtime?: HubSessionRuntimeSnapshot;
}

export interface SpokeRecord {
	spokeId: string;
	kind: "subprocess";
	status: HubSpokeStatus;
	workspaceRoots: string[];
	sessionIds: string[];
	startedAt: number;
	lastSeenAt: number;
	metadata?: Record<string, JsonValue | undefined>;
}

export type ApprovalStatus = "pending" | "approved" | "rejected" | "cancelled";

export interface ApprovalRequestRecord {
	approvalId: string;
	sessionId: string;
	requestedByClientId: string;
	targetClientId?: string;
	status: ApprovalStatus;
	requestedAt: number;
	resolvedAt?: number;
	payload: Record<string, JsonValue | undefined>;
	response?: {
		approved: boolean;
		respondedByClientId: string;
		payload?: Record<string, JsonValue | undefined>;
	};
}

export type CapabilityRequestStatus =
	| "pending"
	| "resolved"
	| "rejected"
	| "cancelled";

export interface CapabilityRequestRecord {
	requestId: string;
	sessionId: string;
	requestedByClientId: string;
	targetClientId?: string;
	capabilityName: string;
	status: CapabilityRequestStatus;
	requestedAt: number;
	resolvedAt?: number;
	payload?: Record<string, JsonValue | undefined>;
	response?: {
		ok: boolean;
		respondedByClientId: string;
		payload?: Record<string, JsonValue | undefined>;
		error?: string;
	};
}

export interface PeerHubRecord {
	peerHubId: string;
	status: "connecting" | "ready" | "disconnected" | "failed";
	connectedAt: number;
	lastSeenAt: number;
	transport: Extract<HubTransportKind, "peer-grpc" | "remote" | "native">;
	metadata?: Record<string, JsonValue | undefined>;
}

export interface ScheduleRecord {
	scheduleId: string;
	name: string;
	cronPattern: string;
	prompt: string;
	workspaceRoot: string;
	cwd?: string;
	modelSelection?: GatewayModelSelection;
	enabled: boolean;
	mode?: "act" | "plan" | "yolo";
	systemPrompt?: string;
	maxIterations?: number;
	timeoutSeconds?: number;
	maxParallel?: number;
	createdAt: number;
	updatedAt: number;
	nextRunAt?: number;
	lastRunAt?: number;
	createdBy?: string;
	tags?: string[];
	runtimeOptions?: HubSessionRuntimeOptions;
	metadata?: Record<string, JsonValue | undefined>;
}

export type ScheduleExecutionStatus =
	| "pending"
	| "running"
	| "success"
	| "completed"
	| "failed"
	| "timeout"
	| "aborted";

export interface ScheduleExecutionRecord {
	executionId: string;
	scheduleId: string;
	sessionId?: string;
	triggeredAt: number;
	startedAt?: number;
	endedAt?: number;
	status: ScheduleExecutionStatus;
	exitCode?: number;
	errorMessage?: string;
	iterations?: number;
	tokensUsed?: number;
	costUsd?: number;
}

export const ONE_TIME_SCHEDULE_CRON_PATTERN = "0";
export const ONE_TIME_SCHEDULE_RUN_AT_METADATA_KEY = "__hubScheduleRunAt";

export const HUB_SCHEDULE_MODES = ["act", "plan", "yolo"] as const;
export type HubScheduleMode = (typeof HUB_SCHEDULE_MODES)[number];

export function isHubScheduleMode(value: unknown): value is HubScheduleMode {
	return HUB_SCHEDULE_MODES.some((mode) => mode === value);
}

export function readHubScheduleMode(
	payload: Record<string, unknown> | undefined,
	defaultWhenAbsent: HubScheduleMode,
): HubScheduleMode;
export function readHubScheduleMode(
	payload: Record<string, unknown> | undefined,
): HubScheduleMode | undefined;
export function readHubScheduleMode(
	payload: Record<string, unknown> | undefined,
	defaultWhenAbsent?: HubScheduleMode,
): HubScheduleMode | undefined {
	if (!payload || !Object.hasOwn(payload, "mode")) {
		return defaultWhenAbsent;
	}
	const mode = payload.mode;
	if (isHubScheduleMode(mode)) {
		return mode;
	}
	throw new Error(`mode must be one of: ${HUB_SCHEDULE_MODES.join(", ")}`);
}

export interface HubScheduleCreateInput {
	name: string;
	cronPattern: string;
	prompt: string;
	workspaceRoot: string;
	cwd?: string;
	modelSelection?: GatewayModelSelection;
	enabled?: boolean;
	mode?: HubScheduleMode;
	systemPrompt?: string;
	maxIterations?: number;
	timeoutSeconds?: number;
	maxParallel?: number;
	createdBy?: string;
	tags?: string[];
	runtimeOptions?: HubSessionRuntimeOptions;
	metadata?: Record<string, JsonValue | undefined>;
}

export interface HubScheduleUpdateInput {
	scheduleId: string;
	name?: string;
	cronPattern?: string;
	prompt?: string;
	workspaceRoot?: string;
	cwd?: string;
	modelSelection?: GatewayModelSelection;
	enabled?: boolean;
	mode?: HubScheduleMode;
	systemPrompt?: string | null;
	maxIterations?: number | null;
	timeoutSeconds?: number | null;
	maxParallel?: number;
	createdBy?: string | null;
	tags?: string[];
	runtimeOptions?: HubSessionRuntimeOptions;
	metadata?: Record<string, JsonValue | undefined>;
}

export type HubCommandName =
	| "client.register"
	| "client.update"
	| "client.unregister"
	| "client.list"
	| "cline.account.get_current"
	| "prompt_commands.list"
	| "prompt_commands.execute"
	| "mention_files.search"
	| "catalog.list"
	| "session.list"
	| "session.create"
	| "session.attach"
	| "session.detach"
	| "session.get"
	| "session.messages"
	| "session.restore"
	| "session.delete"
	| "session.update"
	| "session.update_connection"
	| "session.compaction.get"
	| "session.compaction.update"
	| "session.pending_prompts"
	| "session.update_pending_prompt"
	| "session.remove_pending_prompt"
	| "session.fork"
	| "session.hook"
	| "run.start"
	| "session.send_input"
	| "run.abort"
	| "approval.request"
	| "approval.respond"
	| "capability.request"
	| "capability.progress"
	| "capability.respond"
	| "peer.register"
	| "peer.list_sessions"
	| "peer.attach_session"
	| "peer.detach_session"
	| "peer.proxy_command"
	| "schedule.create"
	| "schedule.list"
	| "schedule.get"
	| "schedule.update"
	| "schedule.delete"
	| "schedule.enable"
	| "schedule.disable"
	| "schedule.trigger"
	| "schedule.list_executions"
	| "schedule.stats"
	| "schedule.active"
	| "schedule.upcoming"
	| "settings.list"
	| "settings.get"
	| "settings.patch"
	| "settings.toggle"
	| "connector.channels"
	| "connector.configure"
	| "connector.delete_config"
	| "cron.event.ingest"
	| "cron.event.list"
	| "cron.event.get"
	| "ui.notify"
	| "ui.show_window";

export const HUB_DEFAULT_COMMAND_TIMEOUT_MS = 30_000;
export const HUB_COMMAND_SLOW_LOG_MS = 5_000;

export function getDefaultHubCommandTimeoutMs(
	command: HubCommandName,
): number | null {
	switch (command) {
		case "run.start":
		case "session.send_input":
			return null;
		default:
			return HUB_DEFAULT_COMMAND_TIMEOUT_MS;
	}
}

export function resolveHubCommandTimeoutMs(
	command: HubCommandName,
	timeoutMs?: number | null,
): number | null {
	return timeoutMs === undefined
		? getDefaultHubCommandTimeoutMs(command)
		: timeoutMs;
}

export interface HubCommandEnvelope {
	version: HubProtocolVersion;
	command: HubCommandName;
	requestId?: string;
	clientId?: string;
	sessionId?: string;
	timeoutMs?: number | null;
	payload?: Record<string, unknown>;
}

export interface HubReplyEnvelope {
	version: HubProtocolVersion;
	requestId?: string;
	ok: boolean;
	payload?: Record<string, unknown>;
	error?: {
		code: string;
		message: string;
		details?: Record<string, unknown>;
	};
}

export type HubEventName =
	| "hub.client.registered"
	| "hub.client.disconnected"
	| "session.created"
	| "session.updated"
	| "session.attached"
	| "session.detached"
	| "session.forked"
	| "session.pending_prompts"
	| "session.pending_prompt_submitted"
	| "run.started"
	| "run.heartbeat"
	| "run.aborted"
	| "run.completed"
	| "run.failed"
	| "iteration.started"
	| "iteration.finished"
	| "assistant.delta"
	| "assistant.finished"
	| "session.notice"
	| "reasoning.delta"
	| "reasoning.finished"
	| "agent.done"
	| "usage.updated"
	| "tool.started"
	| "tool.updated"
	| "tool.finished"
	| "approval.requested"
	| "approval.resolved"
	| "capability.requested"
	| "capability.resolved"
	| "team.progress"
	| "artifact.created"
	| "diff.created"
	| "spoke.started"
	| "spoke.failed"
	| "spoke.stopped"
	| "peer.registered"
	| "peer.session_attached"
	| "peer.session_detached"
	| "schedule.created"
	| "schedule.updated"
	| "schedule.deleted"
	| "schedule.triggered"
	| "schedule.execution_completed"
	| "schedule.execution_failed"
	| "settings.changed"
	| "ui.notify"
	| "ui.show_window"
	| "hub.client.updated";

export interface HubEventEnvelope {
	version: HubProtocolVersion;
	event: HubEventName;
	eventId?: string;
	sessionId?: string;
	clientId?: string;
	sourceHubId?: string;
	timestamp?: number;
	payload?: Record<string, unknown>;
}

export interface HubCapabilityRequestedPayload {
	requestId: string;
	targetClientId: string;
	capabilityName: string;
	payload?: Record<string, unknown>;
}

export interface HubCapabilityResolvedPayload {
	requestId: string;
	targetClientId: string;
	respondedByClientId?: string;
	capabilityName: string;
	ok: boolean;
	cancelled?: boolean;
	payload?: Record<string, unknown>;
	error?: string;
}

export type HubToolExecutorName =
	| "readFile"
	| "search"
	| "bash"
	| "webFetch"
	| "editor"
	| "applyPatch"
	| "skills"
	| "askQuestion"
	| "submit";

export const HUB_TOOL_EXECUTOR_NAMES = [
	"readFile",
	"search",
	"bash",
	"webFetch",
	"editor",
	"applyPatch",
	"skills",
	"askQuestion",
	"submit",
] as const satisfies readonly HubToolExecutorName[];

const HUB_TOOL_EXECUTOR_NAME_SET = new Set<string>(HUB_TOOL_EXECUTOR_NAMES);

export function isHubToolExecutorName(
	value: unknown,
): value is HubToolExecutorName {
	return typeof value === "string" && HUB_TOOL_EXECUTOR_NAME_SET.has(value);
}

export const HUB_TOOL_EXECUTOR_CAPABILITY_PREFIX = "tool_executor.";
export const HUB_CUSTOM_TOOL_CAPABILITY_PREFIX = "custom_tool.";
export const HUB_HOOK_CAPABILITY_PREFIX = "hook.";
export const HUB_COMPACTION_CAPABILITY = "compaction.compact";
export const HUB_CHECKPOINT_CAPABILITY = "checkpoint.create";
export const HUB_MISTAKE_LIMIT_CAPABILITY = "mistake_limit.decide";
export const HUB_USER_INSTRUCTIONS_SNAPSHOT_CAPABILITY =
	"user_instructions.snapshot";

export type HubClientContributionKind =
	| "toolExecutor"
	| "tool"
	| "hook"
	| "compaction"
	| "checkpoint"
	| "mistakeLimit"
	| "userInstructionService";

export interface HubClientContributionBase {
	kind: HubClientContributionKind;
	capabilityName: string;
}

export interface HubClientToolExecutorContribution
	extends HubClientContributionBase {
	kind: "toolExecutor";
	executor: HubToolExecutorName;
}

export interface HubClientToolContribution extends HubClientContributionBase {
	kind: "tool";
	name: string;
	description: string;
	inputSchema: Record<string, JsonValue | undefined>;
	lifecycle?: Record<string, JsonValue | undefined>;
}

export interface HubClientHookContribution extends HubClientContributionBase {
	kind: "hook";
	name: string;
}

export interface HubClientCompactionContribution
	extends HubClientContributionBase {
	kind: "compaction";
	config?: Record<string, JsonValue | undefined>;
}

export interface HubClientCheckpointContribution
	extends HubClientContributionBase {
	kind: "checkpoint";
	config?: Record<string, JsonValue | undefined>;
}

export interface HubClientMistakeLimitContribution
	extends HubClientContributionBase {
	kind: "mistakeLimit";
}

export interface HubClientUserInstructionServiceContribution
	extends HubClientContributionBase {
	kind: "userInstructionService";
}

export type HubClientContribution =
	| HubClientToolExecutorContribution
	| HubClientToolContribution
	| HubClientHookContribution
	| HubClientCompactionContribution
	| HubClientCheckpointContribution
	| HubClientMistakeLimitContribution
	| HubClientUserInstructionServiceContribution;

export interface HubSessionRuntimeOptions {
	mode?: "act" | "plan" | "yolo";
	systemPrompt?: string;
	maxIterations?: number;
	timeoutSeconds?: number;
	thinking?: boolean;
	reasoningEffort?: ReasoningEffort;
	thinkingBudgetTokens?: number;
	checkpointEnabled?: boolean;
	enableTools?: boolean;
	enableSpawn?: boolean;
	enableTeams?: boolean;
	autoApproveTools?: boolean;
	configExtensions?: RuntimeConfigExtensionKind[];
	clientContributions?: HubClientContribution[];
}

export interface HubSessionCreateInput {
	workspaceRoot: string;
	cwd?: string;
	sessionConfig?: Record<string, JsonValue | undefined>;
	metadata?: Record<string, JsonValue | undefined>;
	toolPolicies?: Record<string, JsonValue | undefined>;
	initialMessages?: AgentMessage[];
	agentId?: string;
	agentRole?: string;
	team?: HubTeamMembership;
	modelSelection?: GatewayModelSelection;
	runtimeOptions?: HubSessionRuntimeOptions;
}

export interface HubModelCatalogProvider {
	id: string;
	name: string;
	enabled: boolean;
	defaultModelId?: string;
}

export interface HubModelCatalogModel {
	id: string;
	name?: string;
	supportsThinking?: boolean;
}

export interface HubModelCatalog {
	providers: HubModelCatalogProvider[];
	modelsByProvider: Record<string, HubModelCatalogModel[]>;
	defaultSelection?: GatewayModelSelection;
	defaultWorkspaceRoot?: string;
}

export interface HubSessionAttachInput {
	sessionId: string;
	metadata?: Record<string, JsonValue | undefined>;
	role?: SessionParticipant["role"];
}

export interface HubSessionUpdateInput {
	sessionId: string;
	metadata?: Record<string, JsonValue | undefined>;
}

export interface HubSessionDeleteInput {
	sessionId: string;
	deleteCheckpointRefs?: boolean;
}

export interface HubRunStartInput {
	sessionId: string;
	input?: string | AgentMessage | AgentMessage[];
}

export interface HubApprovalRequestInput {
	sessionId: string;
	targetClientId?: string;
	payload: Record<string, JsonValue | undefined>;
}

export interface HubApprovalRespondInput {
	approvalId: string;
	approved: boolean;
	payload?: Record<string, JsonValue | undefined>;
}

export interface HubCapabilityRequestInput {
	sessionId: string;
	capabilityName: string;
	targetClientId?: string;
	payload?: Record<string, JsonValue | undefined>;
}

export interface HubCapabilityRespondInput {
	requestId: string;
	ok: boolean;
	payload?: Record<string, JsonValue | undefined>;
	error?: string;
}

export interface HubPeerRegisterInput {
	peerHubId?: string;
	transport?: Extract<HubTransportKind, "peer-grpc" | "remote" | "native">;
	metadata?: Record<string, JsonValue | undefined>;
}

export interface HubPeerAttachSessionInput {
	peerHubId: string;
	sessionId: string;
}

export interface HubStateSnapshot {
	hubId: string;
	protocolVersion: HubProtocolVersion;
	sessions: SessionRecord[];
	spokes: SpokeRecord[];
	approvals: ApprovalRequestRecord[];
	capabilityRequests: CapabilityRequestRecord[];
	peers: PeerHubRecord[];
	schedules?: ScheduleRecord[];
	scheduleExecutions?: ScheduleExecutionRecord[];
}

export type HubTransportFrame =
	| { kind: "command"; envelope: HubCommandEnvelope }
	| { kind: "reply"; envelope: HubReplyEnvelope }
	| { kind: "stream.subscribe"; clientId: string; sessionId?: string }
	| { kind: "stream.unsubscribe"; clientId: string; sessionId?: string }
	| { kind: "event"; envelope: HubEventEnvelope };

export interface HubUINotifyPayload {
	title: string;
	body: string;
	severity?: "info" | "warning" | "error";
	sessionId?: string;
	clientId?: string;
}

export interface HubUIShowWindowPayload {
	windowId?: string;
	focus?: boolean;
}
